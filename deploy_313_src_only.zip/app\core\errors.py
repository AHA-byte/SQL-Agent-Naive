class ServiceError(Exception):
    pass
