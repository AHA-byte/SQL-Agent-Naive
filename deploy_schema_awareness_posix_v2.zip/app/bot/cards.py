from botbuilder.core import CardFactory, MessageFactory
from botbuilder.schema import Attachment


def build_summary_text(result: dict) -> str:
    if result.get("status") != "success":
        return f"I could not complete that request: {result.get('error') or result.get('message') or 'Unknown error'}"

    rows = result.get("rows") or []
    row_count = len(rows)

    if row_count == 0:
        return "I ran the query but found no matching rows."

    first = rows[0]
    if first_job_number := first.get("jobNumber"):
        return f"Found {row_count} row(s). Latest job: {first_job_number}."

    first_key = next(iter(first.keys()), None)
    first_value = first.get(first_key) if first_key else "n/a"
    return f"Found {row_count} row(s). First value: {first_value}."


def build_rows_adaptive_card(result: dict, max_rows: int = 5) -> Attachment | None:
    if result.get("status") != "success":
        return None

    rows = result.get("rows") or []
    if not rows:
        return None

    header = {
        "type": "TextBlock",
        "size": "Medium",
        "weight": "Bolder",
        "text": f"SQL Result Preview ({min(len(rows), max_rows)} of {len(rows)})",
        "wrap": True,
    }

    body_blocks: list[dict] = [header]
    for idx, row in enumerate(rows[:max_rows], 1):
        pairs = [f"{k}: {v}" for k, v in row.items()]
        body_blocks.append(
            {
                "type": "TextBlock",
                "text": f"{idx}. " + " | ".join(pairs),
                "wrap": True,
                "spacing": "Medium",
            }
        )

    card = {
        "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
        "type": "AdaptiveCard",
        "version": "1.4",
        "body": body_blocks,
    }
    return CardFactory.adaptive_card(card)


def build_message_activity(result: dict):
    text = build_summary_text(result)
    message = MessageFactory.text(text)

    if card := build_rows_adaptive_card(result):
        message.attachments = [card]

    return message
